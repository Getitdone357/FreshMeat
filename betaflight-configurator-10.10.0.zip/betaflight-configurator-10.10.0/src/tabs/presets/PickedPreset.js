export default class PickedPreset
{
    constructor(preset, presetCli, presetRepo)
    {
        this.preset = preset;
        this.presetCli = presetCli;
        this.presetRepo = presetRepo;
    }
}
