import './jquery';
import 'jquery-ui/dist/jquery-ui';
import 'jquery-textcomplete';
import 'jquery-touchswipe';
import select2 from 'select2';
select2(jQuery);
import 'multiple-select';
import '../../libraries/jquery.nouislider.all.min.js';
import '../../libraries/jquery.flightindicators.js';
